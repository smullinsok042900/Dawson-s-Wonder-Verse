# Dawson’s Wonderverse — Game + Artwork Bundle

This package is based on verified Update 279.

- `index.html` is the original playable, self-contained browser game, unchanged.
- `artwork/` contains the unique raster images extracted from the game’s embedded image data.
- `README_Update279.md` is the original checkpoint README.
- `artwork/` is provided for editing/reference; the original HTML still embeds its artwork and does not require external assets.
- SVG/vector elements and other graphics implemented directly in HTML/CSS/JS remain in `index.html`; they are not independently exported here.
- Browser play and iPhone Safari behavior have not been verified in this packaging step.
- Game save data stored in the browser's localStorage is not included: the game source contains its save logic, but existing player-specific saves must be exported separately from the browser.

To play, open `index.html` in a browser that permits local HTML games, or deploy the ZIP contents to a static web host.
